import unit_tests
unit_tests.testID3AndEvaluate()
unit_tests.testID3AndTest()
unit_tests.testPruning()
unit_tests.testPruning2()
#unit_tests.testPruningOnHouseData('house_votes_84.data')
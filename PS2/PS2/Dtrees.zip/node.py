class Node:
 def __init__(self):
	self.label = None
	self.children = {}
	self.modeResponse = None